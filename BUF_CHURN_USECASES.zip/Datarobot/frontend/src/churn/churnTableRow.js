import React, { useState } from 'react';
import { Tr, Td, Select, Button, Flex, Tooltip, IconButton, Modal, ModalOverlay, ModalContent, ModalHeader, ModalCloseButton, ModalBody } from '@chakra-ui/react';
import { InfoIcon } from '@chakra-ui/icons';
import Graph from './graph/Graph';
// import ExplainTable from './graph/ExplainTable';

const ChurnTableRow = ({ user }) => {
  const [selectedOption, setSelectedOption] = useState('');
  const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);
  const [showTickMark, setShowTickMark] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Offers Option
  const options = [
    { value: "Flat 50% off on next 3 Transactions.", label: "Flat 50% off on next 3 Transactions." },
    { value: "No Annual Fee Applicable.", label: "No Annual Fee Applicable." },
    { value: "Interest Rates upto 12%.", label: "Interest Rates upto 12%." }
  ];

  const handleDropdownChange = (event) => {
    const selectedValue = event.target.value;
    setSelectedOption(selectedValue);
    setIsSubmitDisabled(selectedValue === ''); // Disable the submit button if no option is selected
    setShowTickMark(false);
  };

  const handleSubmit = async () => {
    console.log('Selected Option:', selectedOption, JSON.stringify({ "id": user.Customer_ID, "offer": selectedOption }));

    // console.log(isSubmitDisabled);
    try {
      const response = await fetch('http://4.240.89.151:9003/churn/offer', { //  for deployment
      // const response = await fetch('http://127.0.0.1:9003/churn/offer', {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ "id": user.Customer_ID, "offer": selectedOption }),
      });
      const data = await response.json();
      console.log(data);
      if (data.status === 'ok') {
        setShowTickMark(true); // Show the tick mark
        setTimeout(() => {
          setShowTickMark(false); // Hide the tick mark after a few seconds
        }, 3000); // Adjust the time (in milliseconds) for how long the tick mark should be visible
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  // Function to handle the click on the info icon and open the modal
  const handleToggleExpand = () => {
    // Toggle modal visibility
    setIsModalOpen(!isModalOpen); 
  };


  return (
    <Tr key={user.Customer_ID}>
      <Td>{user.Customer_ID}</Td>
      <Td>{user.Card_Category}</Td>
      <Td textAlign="right">{user.Avg_Utilization_Ratio.toFixed(2)}</Td>
      <Td>
        {user.Prediction >= 1 ? "Yes" : "No"}
        {/* Info Icon */}
        <Tooltip label="Show Graph" placement="top">
          <IconButton
            icon={<InfoIcon />}
            aria-label="Show Graph"
            size="sm"
            colorScheme="blue"
            ml={2}
            onClick={() => handleToggleExpand()}
          />
        </Tooltip>
        {/* Modal to display the graph */}
        <Modal isOpen={isModalOpen} onClose={handleToggleExpand}>
          <ModalOverlay />
          <ModalContent maxH="80vh" maxW="120vh">
            <ModalHeader>Prediction Explanations</ModalHeader>
            <ModalCloseButton />
            <ModalBody overflowY="auto">
              {/* Render the graph inside the modal */}
              <Graph data={user} type="bar" />
              {/* <ExplainTable data={user} /> */}
            </ModalBody>
          </ModalContent>
        </Modal>
      </Td>
      <Td>
        <Flex alignItems="center">
          <Select
            value={selectedOption}
            onChange={handleDropdownChange}
            size="sm"
            w="50%"
            mr={2}
            placeholder="Select an option"
            isDisabled={user.Prediction >= 1 ? false : true}
          >
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>
          <Button
            size="sm"
            colorScheme="blue"
            onClick={handleSubmit}
            isDisabled={isSubmitDisabled}
          >
            Send Offer
          </Button>
          {showTickMark && (
            <span
              style={{
                fontWeight: "bold",
                fontSize: "1.5rem",
                marginLeft: "8px",
                color: "turquoise",
              }}
            >
              ✓
            </span>
          )}
        </Flex>
      </Td>
    </Tr>
  );
};

export default ChurnTableRow;
