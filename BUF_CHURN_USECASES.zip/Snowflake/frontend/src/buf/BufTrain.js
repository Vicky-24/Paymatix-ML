import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";

function BufTrain() {
    const [trainAccuracyThreshold, setTrainAccuracyThreshold] = useState(0.2);
    const [testAccuracyThreshold, setTestAccuracyThreshold] = useState(0.2);
    const [save, setSave] = useState(false);
    const [data, setData] = useState(null);
    
    const location = useLocation();
    
    useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const trainAccuracy = searchParams.get("train_acc");
    const testAccuracy = searchParams.get("test_acc");
    const saveParam = searchParams.get("save");

    setTrainAccuracyThreshold(parseFloat(trainAccuracy));
    setTestAccuracyThreshold(parseFloat(testAccuracy));
    setSave(saveParam === "true");

    const fetchDataFromAPI = async () => {
      try {
        console.log(trainAccuracyThreshold, testAccuracyThreshold, save);
        const response = await fetch(
        `http://4.240.89.151:9011/train/train_buf?train_acc=${trainAccuracyThreshold}&test_acc=${testAccuracyThreshold}&save=${save}` // for deployment
        // `http://localhost:9011/train/train_buf?train_acc=${trainAccuracyThreshold}&test_acc=${testAccuracyThreshold}&save=${save}`
        );
        // const responsedata = await response.json();
        
        if (response.ok) {
            const result = await response.json();
            // console.log(result);
            setData(result);
        } else {
          console.error("Error fetching data:", response.status);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchDataFromAPI(); // Call the function as soon as the component is mounted

    // Clean-up function (optional)
    return () => {
      // You can perform clean-up actions here if needed
    };
  }, [location.search, save, testAccuracyThreshold, trainAccuracyThreshold]); // Empty dependency array ensures the effect runs once after the initial render

  return (
    <div className="train">
      {data ? (
        <div>
          <h2>Data Fetched:</h2>
          <pre>{data}</pre>
        </div>
      ) : (
        <p>Loading data...</p>
      )}
    </div>
  );
}

export default BufTrain;
