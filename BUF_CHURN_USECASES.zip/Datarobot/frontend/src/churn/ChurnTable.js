import React, { useState, useEffect } from 'react';
import { Box, Table, Tr, Td, Th, Thead, Tbody, TableCaption, Spinner, Text, Tooltip, IconButton } from '@chakra-ui/react';
import { InfoIcon, RepeatIcon, ChevronLeftIcon } from '@chakra-ui/icons';
import ChurnTableRow from './churnTableRow';

function ChurnTable({ handleToggleHeader }) {
    const [churnData, setChurnData] = useState([]);
    const [timeData, setTimeData] = useState([]);
    const [showInfo, setShowInfo] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [sortConfig, setSortConfig] = useState({ key: '', direction: '' });

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await fetch('http://4.240.89.151:9003/churn');  // for deployment
            // const response = await fetch('http://127.0.0.1:9003/churn');
            const responsedata = await response.json();
            console.log(responsedata);
            setChurnData(responsedata.data);
            setTimeData(responsedata.time_cost_s);
            setIsLoading(false);
        } catch (error) {
            console.error('Error fetching data:', error);
            setIsLoading(false);
        }
    };

    const handleSort = (key) => {
        let direction = 'asc';

        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }

        setSortConfig({ key, direction });
    };

    const sortedData = churnData.slice().sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
            return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
            return sortConfig.direction === 'asc' ? 1 : -1;
        }
        if (sortConfig.key === 'Prediction') {
            const aValue = a[sortConfig.key] === 'Yes' ? 1 : 0;
            const bValue = b[sortConfig.key] === 'Yes' ? 1 : 0;
            return (aValue - bValue) * (sortConfig.direction === 'asc' ? 1 : -1);
        }
        return 0;
    });

    const handleToggleInfo = () => {
        setShowInfo(!showInfo);
    };

    const handleRefresh = async () => {
        try {
            setIsLoading(true);
            const response = await fetch('http://4.240.89.151:9003/churn/del_cache', { method: 'DELETE' });  //  for deployment
            // const response = await fetch('http://127.0.0.1:9003/churn/del_cache', { method: 'DELETE' });
            const responsedata = await response.json();
            console.log(responsedata);
        } catch (error) {
            console.error('Error refreshing data:', error);
            setIsLoading(false);
        }

        await fetchData();
    };

    const handleBack = () => {
        // Function to go back to the previous page
        // You can use the window.history object for this
        window.history.back();
    };

    const handleToggleHeaderCaption = () => {
        // Call the handleToggleHeader function to toggle header visibility
        handleToggleHeader();
    };

    return (
      <Box>
        <Box p={4} borderWidth={2} borderRadius="md" position="relative">
          {/* Back Arrow Button */}
          <IconButton
            icon={<ChevronLeftIcon />}
            aria-label="Go Back"
            position="absolute"
            top="1rem"
            left="1rem"
            colorScheme="blue"
            onClick={handleBack}
          />

          {/* Refresh Icon */}
          <IconButton
            icon={<RepeatIcon />}
            aria-label="Refresh"
            position="absolute"
            top="1rem"
            right="1rem"
            colorScheme="blue"
            onClick={handleRefresh}
          />
          <Table variant="simple" colorScheme="gray">
            <TableCaption
              onClick={handleToggleHeaderCaption}
              textDecoration="underline"
              fontSize="2xl"
              fontWeight="semibold"
              placement="top"
            >
              Churn Predictions Report
              {/* TimeData Label */}
              <Tooltip
                label={
                  <Box p={1} mt={0.5}>
                    <Text textDecoration="underline" fontSize="md">
                      Time Cost
                    </Text>
                    {Object.entries(timeData).map(([key, value]) => (
                      <Text key={key} fontSize="sm">{`${key}: ${value}s`}</Text>
                    ))}
                  </Box>
                }
                placement="right"
                isOpen={showInfo}
                closeDelay={0}
                hasArrow
              >
                {/* Info Icon */}
                <InfoIcon
                  width={"2rem"}
                  height={"1rem"}
                  onMouseEnter={handleToggleInfo}
                  onMouseLeave={handleToggleInfo}
                ></InfoIcon>
              </Tooltip>
            </TableCaption>

            <Thead>
              <Tr>
                <Th onClick={() => handleSort("Customer_ID")} cursor="pointer">
                  Customer ID{" "}
                  {sortConfig.key === "Customer_ID" && (
                    <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                  )}
                </Th>
                <Th
                  onClick={() => handleSort("Card_Category")}
                  cursor="pointer"
                >
                  Card Category{" "}
                  {sortConfig.key === "Card_Category" && (
                    <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                  )}
                </Th>
                <Th
                  onClick={() => handleSort("Avg_Utilization_Ratio")}
                  cursor="pointer"
                  textAlign="right"
                >
                  Utilization Ratio{" "}
                  {sortConfig.key === "Avg_Utilization_Ratio" && (
                    <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                  )}
                </Th>
                <Th onClick={() => handleSort("Prediction")} cursor="pointer">
                  Churn Risk{" "}
                  {sortConfig.key === "Prediction" && (
                    <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                  )}
                </Th>
                <Th>Action</Th>
              </Tr>
            </Thead>
            <Tbody>
              {isLoading ? (
                <Tr>
                  <Td colSpan={5}>
                    <Box
                      display="flex"
                      justifyContent="center"
                      alignItems="center"
                      height="200px"
                    >
                      <Spinner size="xl" color="blue.500" />
                    </Box>
                  </Td>
                </Tr>
              ) : (
                sortedData.map((user) => (
                  <ChurnTableRow key={user.Customer_ID} user={user} />
                ))
              )}
            </Tbody>
          </Table>
        </Box>
      </Box>
    );
}

export default ChurnTable;
