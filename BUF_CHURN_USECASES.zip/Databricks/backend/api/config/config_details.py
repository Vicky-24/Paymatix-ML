NUM_OF_DATA=500

DATABRICKS_SERVER_HOSTNAME="adb-3960830062951186.6.azuredatabricks.net"
DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/4718fb82472ff65b"
DATABRICKS_ACCESS_TOKEN="dapibf94aaf628e461f7873c823ef6e6ae88-3"
DATABRICKS_CATALOG="hive_metastore"
DATABRICKS_SCHEMA="ml_dataset"

FROM_EMAIL='harvisbanking@gmail.com'
RECIPIENT = ['bhims2@hexaware.com', 'senthilkumarb4@hexaware.com' 'arunkumarl@hexaware.com', 'rajeshsankark@hexaware.com']  # , 'mohammadA1@hexaware.com', 'amansinghc@hexaware.com']
SMTP_PORT=587
SMTP_SERVER='smtp.gmail.com'
EMAILPASSWORD='rrnmymxqxfeznnwu'
EMAIL_TIMEOUT=300

CHURN_TABLE_NAME="churn"
CHURN_MODEL_ENDPOINT="https://adb-3960830062951186.6.azuredatabricks.net/serving-endpoints/churn/invocations"
CHURN_EMAILSUBJECT='New Offers for your Account'
CHURN_EMAILBODY="""\
    <html>
        <body>
            <div>Hi,</div><br>
            <div>You have received the following offer(s)!<br><br>
            +{offer}+
            </div><br><br><br>
            <div>Thanks & Regards,</div><br>
            <div>Hexaware Banking</div>
            <img src='cid:leftSideImage' style='float:left;width:20%;height:20%;'/>
        </body>
    </html>
"""

BUF_TABLE_NAME="buf"
TOLERANT_CUSTOMER_SCORE=37
BUF_MODEL_ENDPOINT="https://adb-3960830062951186.6.azuredatabricks.net/serving-endpoints/buf/invocations"
BUF_EMAILSUBJECT='BUF PREDICTIONS REPORT'
BUF_EMAILBODY="""\
    <html>
    <body>
        <p>Hi,<br>
        Please find attached the list of customers deemed to have fraudulent transactions based on BUF predictions.\n\n
        </p>
        Thanks.
    </body>
    </html>
"""