from .config_details import SF_ACCOUNT, SF_DATABASE, SF_PASSWORD, SF_ROLE, SF_SCHEMA, SF_USER, SF_WAREHOUSE

class DEV:
    SF_ACCOUNT = SF_ACCOUNT
    SF_USER = SF_USER
    SF_PASSWORD = SF_PASSWORD
    SF_ROLE = SF_ROLE
    SF_DATABASE = SF_DATABASE
    SF_SCHEMA = SF_SCHEMA
    SF_WAREHOUSE = SF_WAREHOUSE

class UAT:
    DB_USER = ""
    DB_PASSWORD = ""
    DB_HOST = ""
    DB_NAME = ""
    

class PROD:
    DB_USER = ""
    DB_PASSWORD = ""
    DB_HOST = ""
    DB_NAME = ""


def get_env_obj(env=None):

    _configuration = {}
    if env and env == "DEV":
        _configuration["env"] = DEV()
    elif env and env == "UAT":
        _configuration["env"] = UAT()
    else:
        _configuration["env"] = PROD()
        
    return _configuration