from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel
import time

from cachetools import TTLCache
from datetime import timedelta

from .model.churn_api_model import Customer_Churn
from .config.db import snowflakeObj
from .config.utils import logger
from .config.config_details import *

class ChurnOffer(BaseModel):
    id: str
    offer: str

router = APIRouter()

# Create a cache with a time-to-live (TTL) of 2 hours and enable tagging
cache = TTLCache(maxsize=30, ttl=timedelta(hours=48).total_seconds())

churnobject = Customer_Churn()

@router.get('/churn')
def churn_predict():
    try:
        starttime = time.time()
        logger.info("----------------------CHURN----------------------")
        logger.info("'/churn' api initiated")
        session = snowflakeObj.snowflake_connector(schema="MODELS")
        print('fetching sf data...')
        logger.info(f"DATABASE Engine: {session}")

        # Check if the cache key with the 'churn_data' tag exists in the cache
        churn_cachedata_key = 'sf_churn_data'
        cached_sf_churn_data = cache.get(churn_cachedata_key)

        if cached_sf_churn_data is None:
            print("getting new data from source...")
            sf_scored_data, db_exec_time = churnobject.get_sf_data(session)

            cache[churn_cachedata_key] = sf_scored_data
        else:
            print("using cached data for inferencing...")
            sf_scored_data = cached_sf_churn_data
            db_exec_time = 0

        result = sf_scored_data.round(3).to_dict(orient ='records')
        print('Congrats! Inferencing Completed.')
        print("Done...!")
        logger.info("--------------------CHURN END--------------------")
        
        time_cost = {"database_exec_time": db_exec_time, "total_api_time": round(time.time()-starttime, 3)}
        print(time_cost)
        session.close()
        return {"data" : result, "time_cost_s": time_cost}
    except Exception as api_error:
        print(api_error)
        session.close()
        logger.critical(f"[ERROR]: API CALL: {api_error}")

@router.post('/churn/offer')
def customer_offer_email(offer: ChurnOffer, backgroud_Task: BackgroundTasks):
    logger.info("--------------------CHURN MAIL OFFER--------------------")
    # print(offer)
    id = offer.id
    offer = offer.offer

    ## #    Triggering EMAIL   # ##
    backgroud_Task.add_task(churnobject.triggerMail,id, offer)
    logger.info("------------------CHURN MAIL OFFER END------------------")
    
    return {"message": "Mail Sent", "status": "ok"}

@router.delete('/churn/del_cache')
async def invalidate_cache():
    # Invalidate the cache for the 'sf_churn_data' key
    cache.pop('sf_churn_data', None)
    return {"message": "Cache invalidated for 'sf_churn_data' key."}

@router.get('/train/train_churn')
async def train_churn(train_acc: float = 0.2, test_acc: float = 0.2, save: bool = False):
    logger.info("'/train/train_churn' api called")
    
    if str(save).lower() == 'true':
        save = True
    else:
        save = False
    session = snowflakeObj.snowflake_connector()
    output = session.call(CHURN_TRAIN_SPROC, CHURN_TABLE_NAME, train_acc, test_acc, save)
    session.close()
    
    return output