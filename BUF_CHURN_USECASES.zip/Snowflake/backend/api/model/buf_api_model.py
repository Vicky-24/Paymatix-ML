import pandas as pd
from pandas import DataFrame
import json, os

from datetime import datetime

from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from os.path import basename
import smtplib, ssl
from snowflake.snowpark.functions import col, call_udf, array_construct
from snowflake.snowpark.session import Session

from ..config.config_details import *
from ..config.utils import logger, measure_execution_time

class BUF_CustomerScore:

    @measure_execution_time
    def get_sf_data(self, session: Session) -> DataFrame:
        try:
            print('fetching Snowflake data...')
            logger.info(f"FETCHING DATA FROM Snowflake {BUF_TABLE_NAME}")

            all_columns = ['CUSTOMERID', 'CUSTOMER_NAME', 'BILLING_ADDRESS_LINE_1', 'AVERAGE_DAILY_BALANCE', 'CURRENT_BALANCE_OF_CUSTOMER', 'TOTAL_PURCHASE_AMOUNT', 'CREDIT_LIMIT', 'INCOME_OF_THE_CUSTOMER', 'CURRENTBANKBRANCHID', 'CUSTOMERMONTHSONBOOKS', 'AGE', 'MONTHOFBIRTH_OF_CUSTOMER', 'YEAROFBIRTH_OF_CUSTOMER', 'DUE_DATE_PAYMENT_YEAR', 'DUE_DATE_PAYMENT_MONTH', 'DUE_DATE_PAYMENT_DAY', 'CREDIT_LIMIT_DATE_YEAR', 'CREDIT_LIMIT_DATE_MONTH', 'CREDIT_LIMIT_DATE_DAY', 'STARTING_DATE_OF_RELATIONSHIP_YEAR', 'STARTING_DATE_OF_RELATIONSHIP_MONTH', 'STARTING_DATE_OF_RELATIONSHIP_DAY', 'PHONE', 'BILLING_CITY', 'BILLING_STATE', 'BILLING_COUNTRY', 'BILLING_ZIP', 'EMAIL_DOMAIN']
            
            table = session.table(f'{BUF_TABLE_NAME}') # *list(table.columns)
            result_table = table.select(*list(table.columns), call_udf(f"{BUF_UDF}", array_construct(
                col('AGE'), col('AVERAGE_DAILY_BALANCE'), col('BILLING_CITY'), col('BILLING_COUNTRY'), col('BILLING_STATE'), col('BILLING_ZIP'), col('CREDIT_LIMIT'), col('CREDIT_LIMIT_DATE'), col('CURRENTBANKBRANCHID'), col('CURRENT_BALANCE_OF_CUSTOMER'), col('CUSTOMERMONTHSONBOOKS'), col('DUE_DATE_PAYMENT'), col('EMAIL_ADDRESS'), col('INCOME_OF_THE_CUSTOMER'), col('MONTHOFBIRTH_OF_CUSTOMER'), col('PHONE'), col('STARTING_DATE_OF_RELATIONSHIP'), col('TOTAL_PURCHASE_AMOUNT'), col('YEAROFBIRTH_OF_CUSTOMER')
                )).as_("BUF_SCORE"))
            
            result_df = result_table.to_pandas()
            logger.info(f"RAW SF DATA:\n{result_df.head(1).to_json(orient='records')}")
            
            dataset_all = result_df
            dataset_all = result_df.sample(frac=1).head(NUM_OF_DATA) if NUM_OF_DATA!=0 else dataset_all.sample(frac=1)
            sf_data = dataset_all.reset_index()
            
            ## Save the result to a new table
            session.createDataFrame(sf_data).write.mode("overwrite").save_as_table(f"{BUF_PREDICTED_TABLE_NAME}")
            return sf_data
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT FETCH DATA FROM Snowflake {BUF_TABLE_NAME}: {e}")
            print(e)
            raise e

    def modifyDataFrame(self, raw_data: DataFrame, dataframe: DataFrame) -> DataFrame:
        # logger.info(f"API RESULT GROUPED:\n{dataframe}")
        try:
            """
            SELECT CustomerMonthsOnBooks , ROUND(SUM(Credit_Limit),2) as CreditLimit , ROUND(AVG(CustomerScore),2) as CustomerScore, 
            COUNT(CustomerID) as Total_Num_of_Transactions,  ROUND(SUM(Total_Purchase_Amount),2) as Total_Transactions_Amount 
            FROM local_customertable WHERE CustomerID = '%s' GROUP BY CustomerMonthsOnBooks LIMIT 1;"%(customerid))

            # COLUMNS
            new Total_Num_of_Transactions
            Total_Transactions_Amount
            
            CustomerMonthsOnBooks
            Credit_Limit
            CustomerScore
            # Drop columns: id,	rowId, CustomerMonthsOnBooks, Credit_Limit, CustomerScore
            """

            mod_dataframe = dataframe
            mod_dataframe.drop(columns=["CUSTOMERMONTHSONBOOKS", "CREDIT_LIMIT", "CUSTOMERSCORE", "TOTAL_PURCHASE_AMOUNT", "ID", "ROWID"],errors='ignore', inplace=True)
            mod_dataframe.insert(
                5,
                "CUSTOMERMONTHSONBOOKS",
                list(raw_data.groupby("CUSTOMERID")["CUSTOMERMONTHSONBOOKS"].mean().round()),
            )
            mod_dataframe.insert(
                5,
                "CREDIT_LIMIT",
                list(raw_data.groupby("CUSTOMERID")["CREDIT_LIMIT"].mean().round(2)),
            )
            mod_dataframe.insert(
                5,
                "CUSTOMERSCORE",
                list(raw_data.groupby("CUSTOMERID")["CUSTOMERSCORE"].mean().round(2)),
            )
            mod_dataframe.insert(
                5,
                "TOTAL_TRANSACTIONS_AMOUNT",
                list(raw_data.groupby("CUSTOMERID")["TOTAL_PURCHASE_AMOUNT"].sum()),
            )
            mod_dataframe.insert(
                4,
                "TOTAL_NUM_OF_TRANSACTIONS",
                list(raw_data.groupby("CUSTOMERID").size()),
            )

            mod_dataframe.insert(1, "id", list(mod_dataframe.index.tolist()))

            return mod_dataframe
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT MODFIY DATAFRAME: {e}")
            print(e)

    def prepareMailReport(self, riskycustomers):
        dir = "temp"
        date = datetime.today().strftime("%Y_%m_%d_%H_%M_%S")
        if not "temp" in os.listdir(os.getcwd()):
            try:
                os.mkdir(dir)
            except Exception as e:
                print(e)
        rptlocation = f"{dir}/report_{date}.csv"
        riskycustomers.to_csv(rptlocation, index=False)
        logger.info(f"REPORT NAME '{rptlocation}'")

        return rptlocation

    def prepareMailBody(self, filelocation):
        try:
            with open(filelocation, "rb") as file:
                attachment = MIMEApplication(file.read(), Name=basename(filelocation))
            file.close()
            attachment["Content-Disposition"] = 'attachment; filename="%s"' % basename(
                filelocation
            )
            htmlmsg = MIMEMultipart()
            htmlmsg["From"] = FROM_EMAIL
            htmlmsg["To"] = ", ".join(RECIPIENT)
            htmlmsg["Subject"] = BUF_EMAILSUBJECT
            htmlmsg.attach(MIMEText(BUF_EMAILBODY, "html"))
            htmlmsg.attach(attachment)

            mailobject = htmlmsg.as_string()
        except Exception as e:
            print("Error Creating Mail Body")
            logger.critical(f"[ERROR]: Error in Creating Mail Body: {e}")
            print(e)

        return mailobject

    def sendMail(self, mailobject):
        # logger.info(f"EMAIL BODY:\n{mailobject}")
        try:
            SSL_context = ssl.create_default_context()
            print("sending email now...")
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=EMAIL_TIMEOUT) as server:
                server.starttls(context=SSL_context)
                server.login(FROM_EMAIL, EMAILPASSWORD)
                server.sendmail(FROM_EMAIL, RECIPIENT, mailobject)
                print('EMAIL SENT!')
                server.quit()
            logger.info("EMAIL SENT SUCCESSFULLY!")
        except Exception as e:
            logger.critical(f"[ERROR] CANNOT SEND MAIL: {e}")
            print("EMAIL SERVER ERROR!!\n",e)

    def cleanTempDir(self, file):
        try:
            if os.path.isfile(file) or os.path.islink(file):
                os.unlink(file)
            elif os.path.isdir(file):
                os.remove(file)
            print("temp cleared...")
            logger.info(f"REPORT {file} CLEARED")
        except Exception as e:
            logger.critical("Failed to delete %s. Reason: %s" % (file, e))
            print("Failed to delete %s. Reason: %s" % (file, e))

    
    def triggerMail(self, dataframe):
        print("triggering email...")
        try:
            riskycustomers = dataframe[
                dataframe["CUSTOMERSCORE"] > TOLERANT_CUSTOMER_SCORE
            ]

            logger.info(f"SENDING MAIL TO CUSTOMERS HAVING TOLERANT SCORE ABOVE {TOLERANT_CUSTOMER_SCORE}\n{riskycustomers[['CUSTOMERID','CUSTOMERSCORE']]}")
            if not riskycustomers.empty:
                rptlocation = self.prepareMailReport(riskycustomers)
                mailobject = self.prepareMailBody(rptlocation)
                self.sendMail(mailobject)
                self.cleanTempDir(rptlocation)
        except Exception as e:
            print("[ERROR]: Trigger Mail", e)
            logger.critical(f"[ERROR]: CANNOT SEND MAIL: {e}")

        return 0