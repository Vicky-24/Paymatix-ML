import { useColorMode, Box, Flex, Link, Heading } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

function Home({ handleToggleHeader }) {
    const { colorMode } = useColorMode();
    // const navigate = useNavigate();

    const handleCardClick = () => {
        // navigate('/buf');
    };

    const handleToggleHeaderCaption = () => {
        // Call the handleToggleHeader function to toggle header visibility
        handleToggleHeader();
    };

    return (
        <Box p={4} css={{ minHeight: '65vh' }}>
            <Box
                maxW="75%"
                css={{ minHeight: '65vh' }}
                maxH="85%"
                mx="auto"
                // borderWidth={1}
                borderRadius="md"
                p={4}
            >
                <Heading onClick={handleToggleHeaderCaption} as="h1" fontSize="xl" mb={4} mt={10} textAlign="center">
                    Welcome to the Paymatix AI/ML homepage !
                </Heading>
                <Flex css={{ minHeight: '60vh' }} justifyContent="space-around" alignItems="center">
                    <Link
                        as={RouterLink}
                        to="/buf"
                        w="45%"
                        p={4}
                        borderWidth={1}
                        borderRadius="md"
                        textAlign="center"
                        textDecoration="none"
                        color={colorMode === 'light' ? 'black' : 'white'}
                        bg={colorMode === 'light' ? 'white' : 'gray.800'}
                        backgroundImage={'url(https://ionicframework.com/img/getting-started/ionic-native-card.png)'}
                        backgroundPosition={'right'}
                        backgroundRepeat={'no-repeat'}
                        backgroundSize={'80px'}
                        _hover={{
                            bg: colorMode === 'light' ? 'rgba(128, 128, 128, 0.3)' : 'rgba(55, 55, 55, 0.3)',
                            backgroundImage: 'url(https://ionicframework.com/img/getting-started/ionic-native-card.png)',
                            backgroundPosition: 'right',
                            backgroundRepeat: 'no-repeat',
                            backgroundSize: '120px',
                            textDecoration: 'underline'

                        }} onClick={handleCardClick}
                        css={{
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)', // Add box shadow
                            minHeight: '40vh'
                        }}
                    >
                        <Heading as="h3" size="md" mb={2}>
                            BUF UseCase
                        </Heading>
                        <p>A tool to detect whether a customer is likely to be a fraud or not.</p>
                    </Link>
                    <Link
                        as={RouterLink}
                        to="/churn"
                        w="45%"
                        p={4}
                        borderWidth={1}
                        borderRadius="md"
                        textAlign="center"
                        textDecoration="none"
                        color={colorMode === 'light' ? 'black' : 'white'}
                        bg={colorMode === 'light' ? 'white' : 'gray.800'}
                        backgroundImage={'url(https://ionicframework.com/img/getting-started/theming-card.png)'}
                        backgroundPosition={'right'}
                        backgroundRepeat={'no-repeat'}
                        backgroundSize={'80px'}
                        _hover={{
                            bg: colorMode === 'light' ? 'rgba(128, 128, 128, 0.3)' : 'rgba(55, 55, 55, 0.3)',
                            backgroundImage: 'url(https://ionicframework.com/img/getting-started/theming-card.png)',
                            backgroundPosition: 'right',
                            backgroundRepeat: 'no-repeat',
                            backgroundSize: '120px',
                            textDecoration: 'underline'

                        }}
                        onClick={handleCardClick}
                        css={{
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)', // Add box shadow
                            minHeight: '40vh',
                        }}
                    >
                        <Heading as="h3" size="md" mb={2}>
                            Churn UseCase
                        </Heading>
                        <p>A tool to detect whether a customer is likely to leave (churn) or not.</p>
                    </Link>
                </Flex>
            </Box>
        </Box >
    );
}

export default Home;
