from fastapi import APIRouter, BackgroundTasks, HTTPException

from cachetools import TTLCache
from datetime import timedelta

from .model.buf_api_model import BUF_CustomerScore
from .config.db import sqlServerObj
from .config.utils import logger

import time

router = APIRouter()

# Create a cache with a time-to-live (TTL) of 48 hours and enable tagging
cache = TTLCache(maxsize=30, ttl=timedelta(hours=48).total_seconds())
bufobject = BUF_CustomerScore()

@router.get('/')
async def home():
    return """Welcome To Banking Practice Usecases"""

@router.get('/buf')
async def buf_predict(backgroud_Task: BackgroundTasks):
    try:
        starttime = time.time()
        logger.info("----------------------BUF----------------------")
        logger.info("'/buf' api called")
        
        engine = sqlServerObj.alchemy_connect()
        logger.info(f"DATABASE ENGINE: {engine}")

        # Check if the cache key with the 'buf_data' tag exists in the cache
        buf_cachedata_key = 'adw_buf_data'
        cached_adw_buf_data = cache.get(buf_cachedata_key)

        if cached_adw_buf_data is None:
            print("getting new data from source...")
            # Cache miss: Fetch data from the database
            adw_test_data, db_exec_time = bufobject.get_adw_data(engine)
                        
            # Store the data in the cache with the 'buf_data' key and TTL of 48 hours
            cache[buf_cachedata_key] = adw_test_data
        else:
            print("using cached data for inferencing...")
            adw_test_data = cached_adw_buf_data
            db_exec_time = 0
        buf_api_result, az_inference_time = bufobject.predictCustomerScore(adw_test_data)
        merged_api_result = bufobject.mergeData(adw_test_data,buf_api_result)

        grouped_result = merged_api_result.groupby('CustomerID', as_index=False).first()
        # print(json.loads(grouped_result.to_json(orient ='records')))
        mod_result = bufobject.modifyDataFrame(merged_api_result, grouped_result)
        print(mod_result)
        print('Congrats! Inferencing Completed.')
        ##########################
        #    Triggering EMAIL    #
        backgroud_Task.add_task(bufobject.triggerMail,grouped_result)
        print("Done...!")
        logger.info("--------------------BUF END--------------------")
        result = mod_result.round(2).to_dict(orient ='records')

        time_cost = {"database_exec_time": db_exec_time,"model_inferencing_time": az_inference_time, "total_api_time": round(time.time()-starttime, 3)}
        print(time_cost)
        return {"data" : result, "time_cost_s": time_cost}
    except Exception as api_error:
        print(api_error)
        logger.critical(f"[ERROR]: API CALL: {api_error}")
        raise HTTPException(status_code=503, detail=str(api_error))
        # return {"error": str(api_error)}

@router.delete('/buf/del_cache')
async def invalidate_cache():
    # Invalidate the cache for the 'adw_buf_data' key
    cache.pop('adw_buf_data', None)
    return {"message": "Cache invalidated for 'adw_buf_data' key."}