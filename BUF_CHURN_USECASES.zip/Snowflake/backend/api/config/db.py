# import pyodbc #pymysql #removed pymysql dependecy from the project

from .env import access
from snowflake.snowpark.session import Session

class Query:
    def __init__(self, username, password, db_name, account, role, schema, warehouse = None):
        
        self.db_name = db_name
        self.password = password
        self.username = username
        self.account = account
        self.schema = schema
        self.role = role
        self.warehouse = warehouse

    def snowflake_connector(self, schema = None, warehouse = None):
        try:
            if schema is None:
                schema = self.schema
            if warehouse is None:
                warehouse = self.warehouse
            
            connection_parameters = {
                "account": self.account,
                "user": self.username,
                "password": self.password,
                "role": self.role,
                "database": self.db_name,
                "schema" : schema,
                "warehouse": warehouse
            }
            session = Session.builder.configs(connection_parameters).create()
            print("Connection Successfull!")
        except:
            raise ValueError("error while connecting with db")
        return session

snowflakeObj = Query(access.SF_USER, access.SF_PASSWORD, access.SF_DATABASE, access.SF_ACCOUNT, access.SF_ROLE, access.SF_SCHEMA, access.SF_WAREHOUSE)