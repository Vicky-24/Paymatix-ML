import { useColorMode, Box, Flex, Link, IconButton } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';
import { MoonIcon, SunIcon } from '@chakra-ui/icons';
// import payMatixDark from '../static/Paymatix-Dark.png';
// import payMatixLight from '../static/Paymatix-Light.png';
import mlOpsLightLogo from '../static/MLOps-Black-Font.png';
import mlOpsDarkLogo from '../static/MLOps-White-Font.png';
import azureMlLogo from '../static/azure-ml-logo.png'

function Header() {
    const { colorMode, toggleColorMode } = useColorMode();


    if (colorMode === 'light') {
        return (
            <Box as="header" bg={colorMode === 'light' ? 'gray.200' : 'gray.700'} p={2}>
                <Flex alignItems="center" justifyContent="space-between">
                    <Box as="nav" display="flex">
                        <Link as={RouterLink} to="/">
                            <Box mr={2}>
                                {/* <img src={payMatixLight} alt="Logo" style={{ height: '64px', borderRadius: '4%' }} /> */}
                            </Box>
                        </Link>

                        <Link as={RouterLink} to="/">
                            <Box ml={2}>
                                <img src={mlOpsLightLogo} alt="Logo" style={{ height: '64px', borderRadius: '4%' }} />
                            </Box>
                        </Link>


                        <Box ml={2}>
                            <img src={azureMlLogo} alt="Logo" style={{ height: '55px', borderRadius: '4%', marginTop: '2px' }} />
                        </Box>


                        {/* <Link as={RouterLink} to="/contact">Contact</Link> */}
                    </Box>
                    <IconButton
                        icon={colorMode === 'light' ? <MoonIcon /> : <SunIcon />}
                        onClick={toggleColorMode}
                        aria-label="Toggle Dark Mode"
                        variant="outline"
                    />
                </Flex>
            </Box>
        );
    }
    else {
        return (
            <Box as="header" bg={colorMode === 'light' ? 'gray.200' : 'gray.700'} p={2}>
                <Flex alignItems="center" justifyContent="space-between">
                    <Box as="nav" display="flex">
                        <Link as={RouterLink} to="/">
                            <Box mr={2}>
                                {/* <img src={payMatixDark} alt="Logo" style={{ height: '64px', borderRadius: '4%' }} /> */}
                            </Box>
                        </Link>

                        <Link as={RouterLink} to="/">
                            <Box ml={2}>
                                <img src={mlOpsDarkLogo} alt="Logo" style={{ height: '64px', borderRadius: '4%' }} />
                            </Box>
                        </Link>


                        <Box ml={2}>
                            <img src={azureMlLogo} alt="Logo" style={{ height: '55px', borderRadius: '4%', marginTop: '2px' }} />
                        </Box>


                        {/* <Link as={RouterLink} to="/contact">Contact</Link> */}
                    </Box>
                    <IconButton
                        icon={colorMode === 'light' ? <MoonIcon /> : <SunIcon />}
                        onClick={toggleColorMode}
                        aria-label="Toggle Dark Mode"
                        variant="outline"
                    />
                </Flex>
            </Box>
        );
    }
}

export default Header;
