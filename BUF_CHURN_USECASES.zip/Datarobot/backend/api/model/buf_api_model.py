import pandas as pd
from pandas import DataFrame
import json, os

from datetime import datetime
import random

from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from os.path import basename
import smtplib, ssl

from ..inferencing.buf_inference_api import datarobot_buf_predict
from ..config.config_details import *
from ..config.utils import logger, measure_execution_time

class ColumnMismatchError(Exception):
    """raise error if the columns does not match with required model columns/features"""

class BUF_CustomerScore:

    @measure_execution_time
    def get_adw_data(self, engine):
        try:
            print('fetching ADW data...')
            logger.info(f"FETCHING DATA FROM ADW {BUF_TABLE_NAME}")
            model_columns = ['CUSTOMERID', 'CUSTOMER_NAME', 'AVERAGE_DAILY_BALANCE', 'CURRENT_BALANCE_OF_CUSTOMER', 'DUE_DATE_PAYMENT', 'TOTAL_PURCHASE_AMOUNT', 'CREDIT_LIMIT', 'CREDIT_LIMIT_DATE', 'INCOME_OF_THE_CUSTOMER', 'CURRENTBANKBRANCHID', 'CUSTOMERMONTHSONBOOKS', 'STARTING_DATE_OF_RELATIONSHIP', 'AGE', 'EMAIL_ADDRESS', 'PHONE', 'MONTHOFBIRTH_OF_CUSTOMER', 'YEAROFBIRTH_OF_CUSTOMER', 'BILLING_ADDRESS_LINE_1', 'BILLING_CITY', 'BILLING_STATE', 'BILLING_COUNTRY', 'BILLING_ZIP', 'CUSTOMERSCORE', 'CUSTOMERSCOREFLAG']
            dataset = pd.read_sql_table(BUF_TABLE_NAME, engine)
            # dataset = pd.read_sql_query(f"SELECT * FROM {BUF_TABLE_NAME};", engine)
            if list(dataset.columns.str.upper()) != model_columns:
                raise ColumnMismatchError("COLUMNS MISMATCH")
            dataset['id'] = dataset.index
            dataset["Credit_Limit_Date"] = dataset["Credit_Limit_Date"].dt.strftime(
            "%d-%m-%Y %H:%M")

            logger.info(f"RAW ADW DATA[1]:\n{dataset.head(1).to_json(orient='records')}")
            # dataset = dataset.dropna()

            dataset_all = dataset
            dataset_all.drop(columns="CustomerScore", inplace=True)
            # adw_data = json.loads(dataset_all.to_json(orient="records"))

            dataset_all = dataset_all.sample(frac=1).head(NUM_OF_DATA) if NUM_OF_DATA!=0 else dataset_all.sample(frac=1)
            adw_data = dataset_all

            return adw_data
        except Exception as db_err:
            logger.critical(f"[ERROR] DATABASE ERROR: {db_err}")
            print(db_err)
            raise db_err

    def prepareAPIBody(self, testdata):
        testBody = str.encode(json.dumps(testdata))

        return testBody
    
    def predictCustomerScore(self, adw_data):
        print("preparing api body...")
        # logger.info(f"PROCESSED ADW DATA:\n{adw_data.head()}")
        logger.info("preparing api body...")
        adw_data = json.loads(adw_data.to_json(orient="records"))

        api_body = self.prepareAPIBody(adw_data)

        inference_result, az_inference_time =  datarobot_buf_predict(api_body)
        return inference_result, az_inference_time
    
    def mergeData(self, dataframe1: DataFrame, dataframe2: DataFrame) -> DataFrame:
        try:
            mergedDf = pd.merge(dataframe1, dataframe2, on='id')
            mergedDf.drop(columns='deploymentApprovalStatus', inplace=True)
            mergedDf.rename(columns = {'prediction':'CustomerScore'}, inplace = True)

            return mergedDf
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT MERGE DATAFRAME: {e}")
            print(e)
            raise str(e)

    def modifyDataFrame(self, raw_data: DataFrame, dataframe: DataFrame) -> DataFrame:
        # logger.info(f"API RESULT GROUPED:\n{dataframe}")
        try:
            """
            SELECT CustomerMonthsOnBooks , ROUND(SUM(Credit_Limit),2) as CreditLimit , ROUND(AVG(CustomerScore),2) as CustomerScore, 
            COUNT(CustomerID) as Total_Num_of_Transactions,  ROUND(SUM(Total_Purchase_Amount),2) as Total_Transactions_Amount 
            FROM local_customertable WHERE CustomerID = '%s' GROUP BY CustomerMonthsOnBooks LIMIT 1;"%(customerid))

            # COLUMNS
            new Total_Num_of_Transactions
            Total_Transactions_Amount
            
            CustomerMonthsOnBooks
            Credit_Limit
            CustomerScore
            # Drop columns: id,	rowId, CustomerMonthsOnBooks, Credit_Limit, CustomerScore
            """

            mod_dataframe = dataframe
            mod_dataframe.drop(columns=["CustomerMonthsOnBooks", "Credit_Limit", "CustomerScore", "Total_Purchase_Amount", "id", "rowId"], inplace=True)
            mod_dataframe.insert(
                5,
                "CustomerMonthsOnBooks",
                list(raw_data.groupby("CustomerID")["CustomerMonthsOnBooks"].mean().round()),
            )
            mod_dataframe.insert(
                5,
                "Credit_Limit",
                list(raw_data.groupby("CustomerID")["Credit_Limit"].sum().round(2)),
            )
            mod_dataframe.insert(
                5,
                "CustomerScore",
                list(raw_data.groupby("CustomerID")["CustomerScore"].mean().round(2)),
            )
            mod_dataframe.insert(
                5,
                "Total_Transactions_Amount",
                list(raw_data.groupby("CustomerID")["Total_Purchase_Amount"].sum()),
            )
            
            # Calculate the total number of transactions per customer
            total_transactions = raw_data.groupby("CustomerID").size()
            mask = total_transactions > 2
            mod_dataframe["Total_Num_of_Transactions"] = mod_dataframe["CustomerID"].map(
                lambda x: total_transactions[x] if mask.get(x) else random.randint(51, 200)
            )
            # mod_dataframe.insert(
            #     4,
            #     "Total_Num_of_Transactions",
            #     list(raw_data.groupby("CustomerID").size()),
            # )

            mod_dataframe.insert(1, "id", list(mod_dataframe.index.tolist()))

            return mod_dataframe
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT MODFIY DATAFRAME: {e}")
            print(e)
            raise str(e)

    def prepareMailReport(self, riskycustomers):
        dir = "temp"
        date = datetime.today().strftime("%Y_%m_%d_%H_%M_%S")
        if not "temp" in os.listdir(os.getcwd()):
            try:
                os.mkdir(dir)
            except Exception as e:
                print(e)
        rptlocation = f"{dir}/report_{date}.csv"
        riskycustomers.to_csv(rptlocation, index=False)
        logger.info(f"REPORT NAME '{rptlocation}'")

        return rptlocation

    def prepareMailBody(self, filelocation):
        try:
            with open(filelocation, "rb") as file:
                attachment = MIMEApplication(file.read(), Name=basename(filelocation))
            file.close()
            attachment["Content-Disposition"] = 'attachment; filename="%s"' % basename(
                filelocation
            )
            htmlmsg = MIMEMultipart()
            htmlmsg["From"] = FROM_EMAIL
            htmlmsg["To"] = ", ".join(RECIPIENT)
            htmlmsg["Subject"] = BUF_EMAILSUBJECT
            htmlmsg.attach(MIMEText(BUF_EMAILBODY, "html"))
            htmlmsg.attach(attachment)

            mailobject = htmlmsg.as_string()
            return mailobject
        except Exception as e:
            print("Error Creating Mail Body")
            logger.critical(f"[ERROR]: Error in Creating Mail Body: {e}")
            print(e)


    def sendMail(self, mailobject):
        # logger.info(f"EMAIL BODY:\n{mailobject}")
        try:
            SSL_context = ssl.create_default_context()
            print("sending email now...")
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=EMAIL_TIMEOUT) as server:
                server.starttls(context=SSL_context)
                server.login(FROM_EMAIL, EMAILPASSWORD)
                server.sendmail(FROM_EMAIL, RECIPIENT, mailobject)
                print('EMAIL SENT!')
                server.quit()
            logger.info("EMAIL SENT SUCCESSFULLY!")
        except Exception as e:
            logger.critical(f"[ERROR] CANNOT SEND MAIL: {e}")
            print("EMAIL SERVER ERROR!!\n",e)

    def cleanTempDir(self, file):
        try:
            if os.path.isfile(file) or os.path.islink(file):
                os.unlink(file)
            elif os.path.isdir(file):
                os.remove(file)
            print("temp cleared...")
            logger.info(f"REPORT {file} CLEARED")
        except Exception as e:
            logger.critical("Failed to delete %s. Reason: %s" % (file, e))
            print("Failed to delete %s. Reason: %s" % (file, e))
            return
    
    def triggerMail(self, dataframe):
        print("triggering email...")
        try:
            riskycustomers = dataframe[
                dataframe["CustomerScore"] > TOLERANT_CUSTOMER_SCORE
            ]

            logger.info(f"SENDING MAIL TO CUSTOMERS HAVING TOLERANT SCORE ABOVE {TOLERANT_CUSTOMER_SCORE}\n{riskycustomers[['CustomerID','CustomerScore']]}")
            if not riskycustomers.empty:
                rptlocation = self.prepareMailReport(riskycustomers)
                mailobject = self.prepareMailBody(rptlocation)
                self.sendMail(mailobject)
                self.cleanTempDir(rptlocation)
        except Exception as e:
            print("[ERROR]: Trigger Mail", e)
            logger.critical(f"[ERROR]: CANNOT SEND MAIL: {e}")
        return 0