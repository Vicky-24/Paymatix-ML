from fastapi import APIRouter, BackgroundTasks

from cachetools import TTLCache
from datetime import timedelta

from .model.buf_api_model import BUF_CustomerScore
from .config.db import snowflakeObj
from .config.utils import logger
from .config.config_details import *
import time

router = APIRouter()

# Create a cache with a time-to-live (TTL) of 48 hours and enable tagging
cache = TTLCache(maxsize=30, ttl=timedelta(hours=48).total_seconds())
bufobject = BUF_CustomerScore()

@router.get('/')
async def home():
    print(SF_USER, SF_USER)
    return """Welcome To Banking Practice Usecases"""

@router.get('/buf')
async def buf_predict(backgroud_Task: BackgroundTasks):
    try:
        starttime = time.time()
        logger.info("----------------------BUF----------------------")
        logger.info("'/buf' api called")
        
        session = snowflakeObj.snowflake_connector(schema="USECASES")
        logger.info(f"DATABASE ENGINE: {session}")

        # Check if the cache key with the 'buf_data' tag exists in the cache
        buf_cachedata_key = 'sf_buf_data'
        cached_sf_buf_data = cache.get(buf_cachedata_key)

        if cached_sf_buf_data is None:
            print("getting new data from source...")
            # Cache miss: Fetch data from the database
            sf_scored_data, db_exec_time = bufobject.get_sf_data(session)
            # Store the data in the cache with the 'buf_data' key and TTL of 48 hours
            cache[buf_cachedata_key] = sf_scored_data
        else:
            print("using cached data for inferencing...")
            sf_scored_data = cached_sf_buf_data
            db_exec_time = 0
        
        grouped_result = sf_scored_data.groupby('CUSTOMERID', as_index=False).first()
        mod_result = bufobject.modifyDataFrame(sf_scored_data, grouped_result)

        print('Congrats! Inferencing Completed.')
        ##########################
        #    Triggering EMAIL    #
        backgroud_Task.add_task(bufobject.triggerMail,grouped_result)
        print("Done...!")
        logger.info("--------------------BUF END--------------------")
        result = mod_result.round(2).to_dict(orient ='records')

        # time_cost = {"database_exec_time": db_exec_time,"model_inferencing_time": az_inference_time, "total_api_time": round(time.time()-starttime, 3)}
        time_cost = {"database_exec_time": db_exec_time, "total_api_time": round(time.time()-starttime, 3)}
        print(time_cost)
        session.close()
        return {"data" : result, "time_cost_s": time_cost}
    except Exception as api_error:
        session.close()
        print(api_error)
        logger.critical(f"[ERROR]: API CALL: {api_error}")
        return {"error": api_error}

@router.delete('/buf/del_cache')
async def invalidate_cache():
    # Invalidate the cache for the 'sf_buf_data' key
    cache.pop('sf_buf_data', None)
    return {"message": "Cache invalidated for 'sf_buf_data' key."}

@router.get('/train/train_buf')
async def train_buf(train_acc: float = 0.2, test_acc: float = 0.2, save: bool = False):

    logger.info("'/train/train_buf' api called")
    
    if str(save).lower() == 'true':
        save = True
    else:
        save = False
    
    session = snowflakeObj.snowflake_connector()
    output = session.call(BUF_TRAIN_SPROC, BUF_TABLE_NAME, train_acc, test_acc, save)
    session.close()
    
    return output


##  Harcode API ##
# import pandas as pd
# @router.get('/buf2')
# async def buf_predict(backgroud_Task: BackgroundTasks):
#     try:
#         # starttime = time.time()
#         logger.info("----------------------BUF 2----------------------")
#         logger.info("'/buf2' api called")

#         mod_result = pd.read_csv("modified_hardcode_result.csv")
#         grouped_result = mod_result.groupby("CUSTOMERID", as_index=False).first()
#         # print(mod_result.head())
#         mod_result.drop(
#         columns=[
#             "predictionValues",
#             "predictionExplanations",
#             "shapExplanationsMetadata.baseValue",
#             "shapExplanationsMetadata.remainingTotal",
#             "shapExplanationsMetadata.warnings"
#             ],
#             inplace=True,
#         )

#         mod_result.columns = mod_result.columns.str.upper()

#         print('Congrats! Inferencing Completed.')
#         ##########################
#         #    Triggering EMAIL    #
#         backgroud_Task.add_task(bufobject.triggerMail,grouped_result)
#         print("Done...!")
#         logger.info("--------------------BUF END--------------------")
#         result = mod_result.round(2).to_dict(orient ='records')

#         return {"data" : result, "time_cost_s": 0}
#     except Exception as e:
#         print(str(e))
#         return str(e)
