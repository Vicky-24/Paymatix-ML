import React, { useState } from 'react';
import { ChakraProvider, ColorModeScript, extendTheme } from '@chakra-ui/react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Header from './header/Header';
import Home from './home/Home';
import ChurnTable from './churn/ChurnTable';
import BufTable from './buf/BufTable';

const config = {
  initialColorMode: 'light',
  useSystemColorMode: false,
};
const theme = extendTheme({ config });

function App() {
  const [showHeader, setShowHeader] = useState(false);

  const handleToggleHeader = () => {
    // Call the setShowHeader function with the opposite value of showHeader
    setShowHeader(!showHeader);
  };

  return (
    <ChakraProvider theme={theme}>
      <ColorModeScript initialColorMode={theme.config.initialColorMode} />
      <Router>
      {showHeader && <Header />}
        <Routes>
          <Route path="/" element={<Home handleToggleHeader={handleToggleHeader} />} />
          <Route path="/buf" element={<BufTable handleToggleHeader={handleToggleHeader} />} />
          <Route path="/churn" element={<ChurnTable handleToggleHeader={handleToggleHeader} />} />
          <Route path="*" element={<Home handleToggleHeader={handleToggleHeader} />} />
        </Routes>
      </Router>
    </ChakraProvider>
  );
}

export default App;
