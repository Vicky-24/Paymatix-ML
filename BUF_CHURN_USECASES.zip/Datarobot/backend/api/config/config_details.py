NUM_OF_DATA=500

SQLSERVER_DB_SERVER = "managed-instance-paymatix.public.856aa56af2d6.database.windows.net,3342"
SQLSERVER_DB_DRIVER =  "{ODBC Driver 18 for SQL Server}"
SQLSERVER_DB_NAME = "paymatix_proddb"
SQLSERVER_DB_USER = "ADB_user"
SQLSERVER_DB_PASSWORD = "@d8_MIDBpwd"

FROM_EMAIL = 'harvisbanking@gmail.com'
RECIPIENT = ['bhims2@hexaware.com', 'senthilkumarb4@hexaware.com' 'arunkumarl@hexaware.com', 'rajeshsankark@hexaware.com']  # , 'mohammadA1@hexaware.com', 'amansinghc@hexaware.com']
SMTP_PORT = 587
SMTP_SERVER = 'smtp.gmail.com'
EMAILPASSWORD = 'rrnmymxqxfeznnwu'
EMAIL_TIMEOUT=300

CHURN_TABLE_NAME="churn"
CHURN_MODEL_ENDPOINT="https://hexaware-technologies-limited-partner.dynamic.orm.datarobot.com/predApi/v1.0/deployments/{deployment_id}/predictions"
CHURN_DEPLOYMENT_NAME="63b694c5d1f1fbca6cc8ef63"
CHURN_MODEL_API_KEY="NjRjMzgxZDVlODJiYmRjODdmMzY1YjRkOjZmVDdJOU5EZzdhUnU5N0ZMTjVaS1VOY1BOUXJBdVNiMEN1N2JlM0lVZkU9"
CHURN_DATAROBOT_KEY = 'd25b8e23-288e-a709-fdf4-66e1961dca19'
CHURN_EMAILSUBJECT = 'New Offers for your Account'
CHURN_EMAILBODY = """\
    <html>
        <body>
            <div>Hi,</div><br>
            <div>You have received the following offer(s)!<br><br>
            +{offer}+
            </div><br><br><br>
            <div>Thanks & Regards,</div><br>
            <div>Hexaware Banking</div>
            <img src='cid:leftSideImage' style='float:left;width:20%;height:20%;'/>
        </body>
    </html>
"""

BUF_TABLE_NAME="CustomerTable"
TOLERANT_CUSTOMER_SCORE=37
BUF_MODEL_ENDPOINT="https://hexaware-technologies-limited-partner.dynamic.orm.datarobot.com/predApi/v1.0/deployments/{deployment_id}/predictions"
BUF_DEPLOYMENT_NAME = '63b68da9e2aee3175e5a4b3b'
BUF_MODEL_API_KEY="NjQ0MmIwOTNiZTk5N2Q3NmFlZmMyZThjOnpiNHo2ZmVXUlJWRnJyUEtPVmNkR1VWV1FHdzUzTjVzMXh5R1JCaWRIVDA9"
BUF_DATAROBOT_KEY = 'd25b8e23-288e-a709-fdf4-66e1961dca19'
BUF_EMAILSUBJECT = 'BUF PREDICTIONS REPORT | DataRobot'
BUF_EMAILBODY = """\
    <html>
    <body>
        <p>Hi,<br>
        Please find attached the list of customers deemed to have fraudulent transactions based on BUF predictions.\n\n
        </p>
        Thanks.
    </body>
    </html>
"""