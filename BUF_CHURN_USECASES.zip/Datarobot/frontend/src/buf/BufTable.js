import { useState, useEffect } from "react";
import {
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableCaption,
  Spinner,
  Text,
  Tooltip,
  IconButton,
} from "@chakra-ui/react";
import { InfoIcon, RepeatIcon, ChevronLeftIcon } from "@chakra-ui/icons";

function BufTable({ handleToggleHeader }) {
  const [bufData, setBufData] = useState([]);
  const [timeData, setTimeData] = useState([]);
  const [showInfo, setShowInfo] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [sortConfig, setSortConfig] = useState({ key: "", direction: "" });
  const [showReason, setShowReason] = useState(false);
  const [hoveredRowIndex, setHoveredRowIndex] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  // Define an array of possible reasons
  const reasons = [
    "Credit report history of frequent consumer requests for new credit cards or higher credit limits",
    "Credit limit maxed out and Minimum payment done on previous billing",
  ];

  const fetchData = async () => {
    try {
      const response = await fetch("http://4.240.89.151:9003/buf"); //  for deployment
      // const response = await fetch('http://127.0.0.1:9003/buf');
      const responsedata = await response.json();
      console.log("Data fetched:", response);
      console.log(responsedata);
      setBufData(responsedata.data);
      setTimeData(responsedata.time_cost_s);
      setIsLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error, this.responsedata);
      setIsLoading(false);
    }
  };

  const handleSort = (key) => {
    let direction = "asc";

    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }

    setSortConfig({ key, direction });
  };

  const sortedData = bufData.slice().sort((a, b) => {
    if (a[sortConfig.key] < b[sortConfig.key]) {
      return sortConfig.direction === "asc" ? -1 : 1;
    }
    if (a[sortConfig.key] > b[sortConfig.key]) {
      return sortConfig.direction === "asc" ? 1 : -1;
    }
    // For the last column (Bust_Out_Indication), compare as strings ("Yes" or "No")
    if (sortConfig.key === "CustomerScore") {
      const aValue = a[sortConfig.key] === "Yes" ? 1 : 0;
      const bValue = b[sortConfig.key] === "Yes" ? 1 : 0;
      return (aValue - bValue) * (sortConfig.direction === "asc" ? 1 : -1);
    }
    return 0;
  });

  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="90vh" // Adjust the height to cover the entire viewport
      >
        <Box>
          <Spinner size="xl" color="blue.500" />
          {/* <p>Loading...</p> */}
        </Box>
      </Box>
    );
  }

  const handleToggleInfo = () => {
    setShowInfo(!showInfo);
  };

  const handleToggleReason = () => {
    setShowReason(!showReason);
  };

  const handleRefresh = async () => {
    try {
      setIsLoading(true);
      const response = await fetch("http://4.240.89.151:9003/buf/del_cache", {  //  for deployment
      // const response = await fetch("http://127.0.0.1:9003/buf/del_cache", {
        method: "DELETE",
      });

      const responsedata = await response.json();
      console.log(responsedata);
    } catch (error) {
      console.error("Error refreshing data:", error);
      setIsLoading(false);
    }
    await fetchData();
  };

  const handleBack = () => {
    // Function to go back to the previous page
    // You can use the window.history object for this
    window.history.back();
  };

  const handleToggleHeaderCaption = () => {
    // Call the handleToggleHeader function to toggle header visibility
    handleToggleHeader();
  };

  return (
    <Box>
      <Box p={4} borderWidth={2} borderRadius="md" position="relative">
        {/* Back Arrow Button */}
        <IconButton
          icon={<ChevronLeftIcon />}
          aria-label="Go Back"
          position="absolute"
          top="1rem"
          left="1rem"
          colorScheme="blue"
          onClick={handleBack}
        />

        {/* Refresh Icon */}
        <IconButton
          icon={<RepeatIcon />}
          aria-label="Refresh"
          position="absolute"
          top="1rem"
          right="1rem"
          colorScheme="blue"
          onClick={handleRefresh}
        />
        <Table variant="simple" colorScheme="gray">
          <TableCaption
            onClick={handleToggleHeaderCaption}
            textDecoration="underline"
            fontSize="2xl"
            fontWeight="semibold"
            placement="top"
          >
            BUF Predictions Report
            {/* TimeData Label */}
            <Tooltip
              label={
                <Box p={1} mt={0.5}>
                  <Text textDecoration="underline" fontSize="md">
                    Time Cost
                  </Text>
                  {Object.entries(timeData).map(([key, value]) => (
                    <Text key={key} fontSize="sm">{`${key}: ${value}s`}</Text>
                  ))}
                </Box>
              }
              placement="right"
              isOpen={showInfo}
              closeDelay={0}
              hasArrow
            >
              {/* Info Icon */}
              <InfoIcon
                width={"2rem"}
                height={"1rem"}
                onMouseEnter={handleToggleInfo}
                onMouseLeave={handleToggleInfo}
              ></InfoIcon>
            </Tooltip>
          </TableCaption>

          <Thead>
            <Tr>
              <Th onClick={() => handleSort("CustomerID")} cursor="pointer">
                Customer ID{" "}
                {sortConfig.key === "CustomerID" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
              <Th
                onClick={() => handleSort("CustomerMonthsOnBooks")}
                cursor="pointer"
                textAlign="right"
              >
                Months On Books{" "}
                {sortConfig.key === "CustomerMonthsOnBooks" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
              <Th
                onClick={() => handleSort("Credit_Limit")}
                cursor="pointer"
                textAlign="right"
              >
                Credit Card Limit{" "}
                {sortConfig.key === "Credit_Limit" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
              <Th
                onClick={() => handleSort("Total_Num_of_Transactions")}
                cursor="pointer"
                textAlign="right"
              >
                Total No. of Transactions{" "}
                {sortConfig.key === "Total_Num_of_Transactions" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
              <Th
                onClick={() => handleSort("Total_Transactions_Amount")}
                cursor="pointer"
                textAlign="right"
              >
                Total Transaction Amount{" "}
                {sortConfig.key === "Total_Transactions_Amount" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
              <Th onClick={() => handleSort("CustomerScore")} cursor="pointer">
                Bust Out Indication{" "}
                {sortConfig.key === "CustomerScore" && (
                  <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                )}
              </Th>
            </Tr>
          </Thead>
          <Tbody>
            {sortedData.map((entry, index) => (
              <Tr
                key={entry.CustomerID}
                onMouseEnter={() => setHoveredRowIndex(index)}
                onMouseLeave={() => setHoveredRowIndex(null)}
              >
                <Td>{entry.CustomerID}</Td>
                <Td textAlign="right">{entry.CustomerMonthsOnBooks}</Td>
                <Td textAlign="right">{entry.Credit_Limit.toFixed(2)}</Td>
                <Td textAlign="right">{entry.Total_Num_of_Transactions}</Td>
                <Td textAlign="right">
                  {entry.Total_Transactions_Amount.toFixed(2)}
                </Td>
                {/* <Td>{entry.CustomerScore >= 37 ? "Yes" : "No"}</Td> */}
                <Td>
                  {entry.CustomerScore > 37 ? (
                    <>
                      Yes
                      {hoveredRowIndex === index && (
                        <Tooltip
                          label={
                            <Box p={1} mt={0.5}>
                              <Text fontSize="sm">{`Reason: ${
                                reasons[
                                  Math.floor(Math.random() * reasons.length)
                                ]
                              }`}</Text>
                            </Box>
                          }
                          placement="right"
                          isOpen={showReason}
                          // closeDelay={0}
                          hasArrow
                        >
                          <InfoIcon
                            width={"2rem"}
                            height={"1rem"}
                            onMouseEnter={handleToggleReason}
                            onMouseLeave={handleToggleReason}
                          />
                        </Tooltip>
                      )}
                    </>
                  ) : (
                    "No"
                  )}
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    </Box>
  );
}

export default BufTable;
