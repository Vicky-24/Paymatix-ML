# import urllib.request
import json
import requests
import pandas as pd

from ..config.config_details import BUF_MODEL_ENDPOINT, DATABRICKS_ACCESS_TOKEN
from ..config.utils import logger, measure_execution_time

def create_tf_serving_json(data):       
    return {'dataframe_records': data}     

@measure_execution_time
def score_model(dataset):
    try:
      print('waiting for results from Databricks Model...')
      logger.info('waiting for results from AzureML Model...')   
      headers = {'Authorization': f'Bearer {DATABRICKS_ACCESS_TOKEN}', 'Content-Type': 'application/json'}       
      ds_dict = {'dataframe_split': dataset.to_dict(orient='split')} if isinstance(dataset, pd.DataFrame) else create_tf_serving_json(dataset)       
      data_json = json.dumps(ds_dict, allow_nan=True)       
      response = requests.request(method='POST', headers=headers, url=BUF_MODEL_ENDPOINT, data=data_json)       
      if response.status_code != 200:
          logger.critical(f"[ERROR] INFERENCE ENDPOINT ERROR: {str(response.text)}")
          raise Exception(f'Request failed with status {response.status_code}, {response.text}')
      
      return response.json()
    
    except Exception as error:       
      logger.critical(f"[ERROR] INFERENCE ENDPOINT ERROR: {str(error)}")       
      print(error)
      return None
