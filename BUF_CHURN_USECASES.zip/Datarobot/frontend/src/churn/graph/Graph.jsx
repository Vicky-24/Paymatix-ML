import { React, useEffect, useState } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { Box, ChakraProvider, ColorModeScript, useColorMode } from "@chakra-ui/react";
import ExplainTable from "./ExplainTable";

const Graph = ({ data, type }) => {
  // Get the current color mode from Chakra UI
  const { colorMode } = useColorMode();
  const [predictionExplanation, setPredictionExplanation] = useState([]);

  // console.log("data\n", data);
  // console.log("predictionExplanation ", predictionExplanation);
  useEffect(() => {
    setPredictionExplanation(data.predictionExplanations);
  }, [predictionExplanation]);
  

  const options = {
    chart: {
      type: type === "bar" ? "bar" : undefined,
      backgroundColor: colorMode === "dark" ? "#333333" : "#FFFFFF",
      style: {
        fontFamily: "sans-serif",
        color: colorMode === "light" ? "#FFFFFF" : "#000000",
      },
    },
    title: {
      text: "Prediction Explanations",
      style: {
        color: colorMode === "dark" ? "#FFFFFF" : "#000000",
      },
    },
    xAxis: {
      categories: predictionExplanation.map((explanation) => explanation.feature),
      labels: {
        style: {
          color: colorMode === "dark" ? "#FFFFFF" : "#000000",
          fontSize: "12px", // Adjust the font size of xAxis labels
        },
      },
    },
    yAxis: {
      title: {
        text: "Strength",
        style: {
          color: colorMode === "dark" ? "#FFFFFF" : "#000000",
        },
      },
      labels: {
        style: {
          color: colorMode === "dark" ? "#FFFFFF" : "#000000",
        },
      },
    },
    legend: {
      enabled: false,
      itemStyle: {
        color: colorMode === "dark" ? "#FFFFFF" : "#000000",
        // onclick: console.log("clickkkkkkk"),
      },
    },
    colors: colorMode === "dark" ? ["#6685ba"] : ["#2caffe"], // Customize the series colors

    plotOptions: {
      bar: {
        tooltip: {
          headerFormat: '<b>{point.key}</b><br>',
        },
      },
      series: {
        pointWidth: 35
      }
    },
    series: [{
      name: "Strength",
      data: predictionExplanation.map((explanation) => Math.round(explanation.strength * 100) / 100),
      dataLabels: {
        style: {
          fontFamily: "sans-serif",
        },
      },
    }],
  };


  return (
    <ChakraProvider>
      <ColorModeScript initialColorMode={colorMode} />
      <Box p={2} shadow="md" borderWidth="1px" display="flex" flexDirection="column" alignItems="center">
        <div style={{ minWidth: "695px", flex: "1" }}>
          <HighchartsReact highcharts={Highcharts} options={options} />
        </div>
      </Box>
      <ExplainTable data={predictionExplanation} />
    </ChakraProvider>
  );
};

export default Graph;
