// import React from "react";
// import { Flex, Heading } from "@chakra-ui/react";
// import Graph from "./Graph";
// import ExplainTable from "./ExplainTable";

// const APIResponse = {
//     "data": [
//         {
//             "rowId": 0,
//             "prediction": 0.0,
//             "predictionThreshold": 0.5,
//             "predictionValues": [
//                 {
//                     "label": 1.0,
//                     "value": 0.0589925339
//                 },
//                 {
//                     "label": 0.0,
//                     "value": 0.9410074661
//                 }
//             ],
//             "predictionExplanations": [
//                 {
//                     "label": 1.0,
//                     "feature": "Total_Trans_Ct",
//                     "featureValue": 15.0,
//                     "strength": 4.4118851592,
//                     "qualitativeStrength": "+++"
//                 },
//                 {
//                     "label": 1.0,
//                     "feature": "Total_Ct_Chng_Q4_Q1",
//                     "featureValue": 1.5,
//                     "strength": -2.4622543614,
//                     "qualitativeStrength": "--"
//                 },
//                 {
//                     "label": 1.0,
//                     "feature": "Total_Trans_Amt",
//                     "featureValue": 25,
//                     "strength": -1.777377849,
//                     "qualitativeStrength": "--"
//                 }
//             ],
//             "passthroughValues": {
//                 "id": 0
//             },
//             "deploymentApprovalStatus": "APPROVED"
//         }]
// };

// const Explain = ( { handleToggleHeader } ) => {
//   const { predictionExplanations } = APIResponse.data[0];

//   const handleToggleHeaderCaption = () => {
//     // Call the handleToggleHeader function to toggle header visibility
//     handleToggleHeader();
// };

//   return (
//     <Flex direction="column" p={8}>
//       <Heading onClick={handleToggleHeaderCaption} size="lg">Prediction Explanations</Heading>
//       <Graph data={predictionExplanations} type="bar" />
//       <ExplainTable data={predictionExplanations} />
//     </Flex>
//   );
// };

// export default Explain;
