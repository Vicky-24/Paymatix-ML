
from .env import access
from databricks import sql
from sqlalchemy.engine import URL
from sqlalchemy import create_engine

class Query:
    def __init__(self, host_or_server, http_path, token, catalog, schema):
        self.token = token
        self.schema = schema
        self.catalog = catalog
        self.http_path = http_path
        self.host_or_server = host_or_server

    def alchemy_connect(self):
        try:
            # sqlEngine = sql.connect(
            #         server_hostname = self.host_or_server,
            #         http_path = self.http_path,
            #         access_token = self.token,
            #         catalog = self.catalog,
            #         schema = self.schema)
            conn_string = (
                    "databricks://token:{token}@{host}?http_path={http_path}&catalog={catalog}&schema={schema}".format(
                    token=self.token,
                    host=self.host_or_server,
                    schema=self.schema,
                    catalog=self.catalog,
                    http_path=self.http_path
                    ))
            sqlEngine = create_engine(conn_string)
            
            return sqlEngine
        except Exception as e:
            print(e)
            return "database connection failed\n{e}".format(e)
    # def execute(self, sql):
    #     with self.connection().cursor() as cursor:
    #         cursor.execute(sql)
    #         # fetchone -> to read single data
    #         result = cursor.fetchall()
    #         return result

# cursor.close()
# connection.close()
sqlServerObj = Query(access.DATABRICKS_SERVER_HOSTNAME, access.DATABRICKS_HTTP_PATH, access.DATABRICKS_ACCESS_TOKEN, access.DATABRICKS_CATALOG, access.DATABRICKS_SCHEMA)
