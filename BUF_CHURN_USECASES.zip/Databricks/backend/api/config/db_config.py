from .config_details import DATABRICKS_SERVER_HOSTNAME, DATABRICKS_HTTP_PATH, DATABRICKS_ACCESS_TOKEN ,DATABRICKS_CATALOG, DATABRICKS_SCHEMA
class DEV:
    DATABRICKS_SERVER_HOSTNAME = DATABRICKS_SERVER_HOSTNAME
    DATABRICKS_HTTP_PATH = DATABRICKS_HTTP_PATH
    DATABRICKS_ACCESS_TOKEN = DATABRICKS_ACCESS_TOKEN
    DATABRICKS_CATALOG = DATABRICKS_CATALOG
    DATABRICKS_SCHEMA = DATABRICKS_SCHEMA

class UAT:
    DB_USER = ""
    DB_PASSWORD = ""
    DB_HOST = ""
    DB_NAME = ""
    

class PROD:
    DB_USER = ""
    DB_PASSWORD = ""
    DB_HOST = ""
    DB_NAME = ""


def get_env_obj(env=None):

    _configuration = {}
    if env and env == "DEV":
        _configuration["env"] = DEV()
    elif env and env == "UAT":
        _configuration["env"] = UAT()
    else:
        _configuration["env"] = PROD()
        
    return _configuration