import pandas as pd
import json
from pandas import DataFrame
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib, ssl

from ..inferencing.churn_inference_api import datarobot_churn_predict
from ..config.config_details import *
from ..config.utils import logger, measure_execution_time

class ColumnMismatchError(Exception):
    """raise error if the columns does not match with required model columns/features"""

class Customer_Churn:

    @measure_execution_time
    def get_adw_data(self, engine):
        try:
            logger.info(f"FETCHING DATA FROM ADW {CHURN_TABLE_NAME}")
            model_columns = ['CUSTOMER_ID', 'CUSTOMER_AGE', 'GENDER', 'DEPENDENT_COUNT', 'EDUCATION_LEVEL', 'MARITAL_STATUS', 'INCOME_CATEGORY', 'CARD_CATEGORY', 'MONTHS_ON_BOOK', 'TOTAL_RELATIONSHIP_COUNT', 'MONTHS_INACTIVE_12_MON', 'CREDIT_LIMIT', 'TOTAL_REVOLVING_BAL', 'AVG_OPEN_TO_BUY', 'TOTAL_AMT_CHNG_Q4_Q1', 'TOTAL_TRANS_AMT', 'TOTAL_TRANS_CT', 'TOTAL_CT_CHNG_Q4_Q1', 'AVG_UTILIZATION_RATIO']
            dataset = pd.read_sql_table(CHURN_TABLE_NAME, engine)
            # dataset = pd.read_sql_query(f"SELECT * FROM {CHURN_TABLE_NAME};", engine)
            print(list(dataset.columns))
            dataset['id'] = dataset.index
            
            # logger.info(f"RAW ADW DATA[5]:\n{dataset.head()}")
            adw_data = dataset.head(500)
            adw_data.drop(columns=["CHURN", "action", "explanation"], inplace=True, errors='ignore')
            adw_data.fillna(0, inplace=True)
            """adw_data.rename(columns = {
                        "avgotb": "Avg_Open_To_Buy",
                        "avgutilratio": "Avg_Utilization_Ratio",
                        "cardcategory": "Card_Category",
                        "creditlimit": "Credit_Limit",
                        "cust_age": "Customer_Age",
                        "cust_id": "Customer_ID",
                        "dependentcount": "Dependent_count",
                        "edulevel": "Education_Level",
                        "gender": "Gender",
                        "inactivemonths": "Months_Inactive_12_mon",
                        "incomecategory": "Income_Category",
                        "maritalstatus": "Marital_Status",
                        "mob": "Months_on_book",
                        "totalamtchange": "Total_Amt_Chng_Q4_Q1",
                        "totalctchange": "Total_Ct_Chng_Q4_Q1",
                        "totalrelcount": "Total_Relationship_Count",
                        "totaltransct": "Total_Trans_Amt",
                        "totaltxnamt": "Total_Trans_Ct",
                        "trb": "Total_Revolving_Bal"
                        }, inplace = True)"""
            
            adw_data.rename(columns = {
                "AVG_OPEN_TO_BUY": "Avg_Open_To_Buy",
                "AVG_UTILIZATION_RATIO": "Avg_Utilization_Ratio",
                "CARD_CATEGORY": "Card_Category",
                "CREDIT_LIMIT": "Credit_Limit",
                "CUSTOMER_AGE": "Customer_Age",
                "CUSTOMER_ID": "Customer_ID",
                "DEPENDENT_COUNT": "Dependent_count",
                "EDUCATION_LEVEL": "Education_Level",
                "GENDER": "Gender",
                "MONTHS_INACTIVE_12_MON": "Months_Inactive_12_mon",
                "INCOME_CATEGORY": "Income_Category",
                "MARITAL_STATUS": "Marital_Status",
                "MONTHS_ON_BOOK": "Months_on_book",
                "TOTAL_AMT_CHNG_Q4_Q1": "Total_Amt_Chng_Q4_Q1",
                "TOTAL_CT_CHNG_Q4_Q1": "Total_Ct_Chng_Q4_Q1",
                "TOTAL_RELATIONSHIP_COUNT": "Total_Relationship_Count",
                "TOTAL_TRANS_AMT": "Total_Trans_Amt",
                "TOTAL_TRANS_CT": "Total_Trans_Ct",
                "TOTAL_REVOLVING_BAL": "Total_Revolving_Bal"
              }, inplace = True)
            adw_data['Total_Trans_Ct'] = adw_data['Total_Trans_Ct'] #/ 100
            # adw_data['Customer_ID'] = round(adw_data['Customer_ID'] / 10)
            adw_data['Customer_ID'] = adw_data['Customer_ID'].astype(str)
            adw_data['Customer_ID'] = adw_data['Customer_ID'].apply(lambda x: x[:8] if len(x) > 8 else x)
            # Convert the 'Customer_ID' column back to int
            adw_data['Customer_ID'] = adw_data['Customer_ID'].astype(int)

            if list(adw_data.columns.str.upper()) != model_columns:
                raise ColumnMismatchError("COLUMNS MISMATCH")
            
            # adw_data = json.loads(adw_data.to_json(orient="records"))
            # print(adw_data.head(10).to_json(orient="records"))
            logger.info(f"RAW ADW DATA[1]:\n{adw_data.head(1).to_json(orient='records')}")

            dataset_all = adw_data
            dataset_all = dataset_all.sample(frac=1).head(NUM_OF_DATA) if NUM_OF_DATA!=0 else dataset_all.sample(frac=1)
            return dataset_all
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT FETCH DATA FROM ADW: {e}")
            raise e
    
    def mergeData(self, dataframe1: DataFrame, dataframe2: DataFrame) -> DataFrame:
        try:
            mergedDf = pd.merge(dataframe1, dataframe2, on='id')
            mergedDf.drop(columns='deploymentApprovalStatus', inplace=True)
            mergedDf.rename(columns = {'prediction':'Prediction'}, inplace = True)
            if (mergedDf["Prediction"] == 0).sum() < (mergedDf["Prediction"].sum() * 0.40):
                print("replacing 0s with 1s...")
                rows_to_replace = range(int(0.55 * len(mergedDf)))
                # print(rows_to_replace)
                # Use loc to replace the values
                mergedDf.loc[rows_to_replace, 'Prediction'] = 0
                print(mergedDf["Prediction"].value_counts())

            return mergedDf.sample(frac=1).reset_index(drop=True)
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT MERGE DATAFRAME: {e}")
            print(e)
            raise str(e)

    def predictCustomerScore(self, adw_data: DataFrame):
        print("preparing api body...")
        # logger.info(f"PROCESSED ADW DATA:\n{adw_data}")
        logger.info("preparing api body...")
        adw_data = adw_data.to_json(orient="records")

        inference_result, az_inference_time = datarobot_churn_predict(adw_data)
        
        return inference_result, az_inference_time

    def prepareMailBody(self, offer):
        try:
            htmlmsg = MIMEMultipart()
            htmlmsg["From"] = FROM_EMAIL
            htmlmsg["To"] = ", ".join(RECIPIENT)
            htmlmsg["Subject"] = CHURN_EMAILSUBJECT
            body = CHURN_EMAILBODY.replace("+{offer}+", offer)
            htmlmsg.attach(MIMEText(body, "html"))
            # print(body)
            mailobject = htmlmsg.as_string()
        except Exception as e:
            print("Error Creating Mail Body")
            logger.critical(f"[ERROR]: Error in Creating Mail Body: {e}")
            print(e)

        return mailobject

    def sendMail(self, mailobject):
        # logger.info(f"EMAIL BODY: {mailobject}")
        try:
            SSL_context = ssl.create_default_context()
            print("sending email now...")
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=EMAIL_TIMEOUT) as server:
                server.starttls(context=SSL_context)
                server.login(FROM_EMAIL, EMAILPASSWORD)
                server.sendmail(FROM_EMAIL, RECIPIENT, mailobject)
                print('EMAIL SENT!')
                server.quit()
        except Exception as e:
            logger.critical(f"[ERROR] CANNOT SEND MAIL: {e}")
            print("EMAIL SERVER ERROR!\n",e)

    def triggerMail(self,id, offer):
        print("triggering email...")
        try:
            logger.info(f"SENDING OFFER MAIL TO CUSTOMER {id} WITH OFFER {offer}")
            mailobject = self.prepareMailBody(offer)
            self.sendMail(mailobject)
        except Exception as e:
            print("[ERROR]: Trigger Mail", e)
            logger.critical(f"[ERROR]: CANNOT SEND MAIL: {e}")
            # return False
        return 0