import React from "react";
import { Box, Table, Thead, Tbody, Tr, Th, Td } from "@chakra-ui/react";

const ExplainTable = ({data}) => {

  // console.log(data);
  return (
    <Box p={4} shadow="md" borderWidth="1px">
      <Table variant="striped">
        <Thead>
          <Tr>
            <Th>Qualitative Strength</Th>
            <Th>Feature</Th>
            <Th>Value</Th>
          </Tr>
        </Thead>
        <Tbody>
          {data.map((explanation, index) => (
            <Tr key={index}>
              <Td>{explanation.qualitativeStrength}</Td>
              <Td>{explanation.feature}</Td>
              <Td>{explanation.featureValue}</Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Box>
  );
};

export default ExplainTable;
