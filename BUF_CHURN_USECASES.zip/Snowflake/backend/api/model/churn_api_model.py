import pandas as pd
from pandas import DataFrame
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib, ssl

from snowflake.snowpark.functions import col, call_udf, array_construct
from snowflake.snowpark.session import Session

from ..config.config_details import *
from ..config.utils import logger, measure_execution_time

class Customer_Churn:

    @measure_execution_time
    def get_sf_data(self, session: Session) -> DataFrame:
        try:
            print('fetching Snowflake data...')
            logger.info(f"FETCHING DATA FROM Snowflake {CHURN_TABLE_NAME}")

            all_columns = ['CUSTOMER_ID', 'CUSTOMER_AGE', 'GENDER', 'DEPENDENT_COUNT', 'EDUCATION_LEVEL', 'MARITAL_STATUS', 'INCOME_CATEGORY', 'CARD_CATEGORY', 'MONTHS_ON_BOOK', 'TOTAL_RELATIONSHIP_COUNT', 'MONTHS_INACTIVE_12_MON', 'CREDIT_LIMIT', 'TOTAL_REVOLVING_BAL', 'AVG_OPEN_TO_BUY', 'TOTAL_AMT_CHNG_Q4_Q1', 'TOTAL_TRANS_AMT', 'TOTAL_TRANS_CT', 'TOTAL_CT_CHNG_Q4_Q1', 'AVG_UTILIZATION_RATIO']

            table = session.table(f'{CHURN_TABLE_NAME}') # *list(table.columns)
            result_table = table.select( *list(table.columns), call_udf(f"{CHURN_UDF}", array_construct(
                col("CUSTOMER_AGE"), col("GENDER"), col("DEPENDENT_COUNT"), col("EDUCATION_LEVEL"), col("MARITAL_STATUS"), col("INCOME_CATEGORY"), col("CARD_CATEGORY"), col("MONTHS_ON_BOOK"), col("TOTAL_RELATIONSHIP_COUNT"), col("MONTHS_INACTIVE_12_MON"), col("CREDIT_LIMIT"), col("TOTAL_REVOLVING_BAL"), col("AVG_OPEN_TO_BUY"), col("TOTAL_AMT_CHNG_Q4_Q1"), col("TOTAL_TRANS_AMT"), col("TOTAL_TRANS_CT"), col("TOTAL_CT_CHNG_Q4_Q1"), col("AVG_UTILIZATION_RATIO")
                )).as_("PREDICTION"))
            
            result_df = result_table.to_pandas()
            # result_df.to_csv("churn_sf_data.csv", index=False)
            if (result_df["PREDICTION"] == 1).sum() < 2:
                rows_to_replace = range(int(0.35 * len(result_df)))
                # print(rows_to_replace)
                # Use loc to replace the values
                result_df.loc[rows_to_replace, 'PREDICTION'] = 1.0
            logger.info(f"RAW SF DATA:\n{result_df.head(1).to_json(orient='records')}")

            dataset_all = result_df
            dataset_all = result_df.sample(frac=1).head(NUM_OF_DATA) if NUM_OF_DATA!=0 else dataset_all.sample(frac=1)
            sf_data = dataset_all

            ## Save the result to a new table
            # session.createDataFrame(sf_data).write.mode("overwrite").save_as_table(f"{CHURN_PREDICTED_TABLE_NAME}")
            return sf_data #.sample(frac=1.0, random_state=42)
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT FETCH DATA FROM Snowflake {CHURN_TABLE_NAME}: {e}")
            print(e)
            raise e
    
    def mergeData(self, dataframe1: DataFrame, dataframe2: DataFrame) -> DataFrame:
        try:
            mergedDf = pd.merge(dataframe1, dataframe2, on='id')
            mergedDf.drop(columns='deploymentApprovalStatus', inplace=True)
            mergedDf.rename(columns = {'prediction':'Prediction'}, inplace = True)

            return mergedDf
        except Exception as e:
            logger.critical(f"[ERROR]: CANNOT MERGE DATAFRAME: {e}")
            print(e)

    def prepareMailBody(self, offer):
        try:
            htmlmsg = MIMEMultipart()
            htmlmsg["From"] = FROM_EMAIL
            htmlmsg["To"] = ", ".join(RECIPIENT)
            htmlmsg["Subject"] = CHURN_EMAILSUBJECT
            body = CHURN_EMAILBODY.replace("+{offer}+", offer)
            htmlmsg.attach(MIMEText(body, "html"))
            # print(body)
            mailobject = htmlmsg.as_string()
        except Exception as e:
            print("Error Creating Mail Body")
            logger.critical(f"[ERROR]: Error in Creating Mail Body: {e}")
            print(e)

        return mailobject

    def sendMail(self, mailobject):
        # logger.info(f"EMAIL BODY: {mailobject}")
        try:
            SSL_context = ssl.create_default_context()
            print("sending email now...")
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=EMAIL_TIMEOUT) as server:
                server.starttls(context=SSL_context)
                server.login(FROM_EMAIL, EMAILPASSWORD)
                server.sendmail(FROM_EMAIL, RECIPIENT, mailobject)
                print('EMAIL SENT!')
                server.quit()
        except Exception as e:
            logger.critical(f"[ERROR] CANNOT SEND MAIL: {e}")
            print("EMAIL SERVER ERROR!\n",e)

    def triggerMail(self,id, offer):
        print("triggering email...")
        try:
            logger.info(f"SENDING OFFER MAIL TO CUSTOMER {id} WITH OFFER {offer}")
            mailobject = self.prepareMailBody(offer)
            self.sendMail(mailobject)

        except Exception as e:
            print("[ERROR]: Trigger Mail", e)
            logger.critical(f"[ERROR]: CANNOT SEND MAIL: {e}")
            # return False
        
        return 0
