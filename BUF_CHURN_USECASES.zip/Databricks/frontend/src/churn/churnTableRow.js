import React, { useState } from 'react';
import { Tr, Td, Select, Button, Flex } from '@chakra-ui/react';

const ChurnTableRow = ({ user }) => {
  const [selectedOption, setSelectedOption] = useState('');
  const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);
  const [showTickMark, setShowTickMark] = useState(false);
  
  // Offers Option
  const options = [
    { value: "Flat 50% off on next 3 Transactions.", label: "Flat 50% off on next 3 Transactions." },
    { value: "No Annual Fee Applicable.", label: "No Annual Fee Applicable." },
    { value: "Interest Rates upto 12%.", label: "Interest Rates upto 12%." }
  ];

  const handleDropdownChange = (event) => {
    const selectedValue = event.target.value;
    setSelectedOption(selectedValue);
    setIsSubmitDisabled(selectedValue === ''); // Disable the submit button if no option is selected
    setShowTickMark(false);
  };

  const handleSubmit = async () => {
    console.log('Selected Option:', selectedOption, JSON.stringify({ "id": user.CUSTOMER_ID, "offer": selectedOption }));

    // console.log(isSubmitDisabled);
    try {
      const response = await fetch('http://4.240.89.151:9015/churn/offer', { //  for deployment
      // const response = await fetch('http://127.0.0.1:9015/churn/offer', {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ "id": JSON.stringify(user.CUSTOMER_ID), "offer": selectedOption }),
      });
      const data = await response.json();
      console.log(data);
      if (data.status === 'ok') {
        setShowTickMark(true); // Show the tick mark
        setTimeout(() => {
          setShowTickMark(false); // Hide the tick mark after a few seconds
        }, 3000); // Adjust the time (in milliseconds) for how long the tick mark should be visible
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  return (
    <Tr key={user.CUSTOMER_ID}>
      <Td textAlign="left">{user.CUSTOMER_ID}</Td>
      <Td>{user.CARD_CATEGORY}</Td>
      <Td textAlign="right">{user.AVG_UTILIZATION_RATIO.toFixed(2)}</Td>
      <Td>{user.PREDICTION >= 1 ? "Yes" : "No"}</Td>
      <Td>
        <Flex alignItems="center">
          <Select
            value={selectedOption}
            onChange={handleDropdownChange}
            size="sm"
            w="50%"
            mr={2}
            placeholder="Select an option"
            isDisabled={user.PREDICTION >= 1 ? false : true}
          >
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>
          <Button
            size="sm"
            colorScheme="blue"
            onClick={handleSubmit}
            isDisabled={isSubmitDisabled}
          >
            Send Offer
          </Button>
          {showTickMark && (
            <span
              style={{
                fontWeight: "bold",
                fontSize: "1.5rem",
                marginLeft: "8px",
                color: "turquoise",
              }}
            >
              ✓
            </span>
          )}
        </Flex>
      </Td>
    </Tr>
  );
};

export default ChurnTableRow;
