import requests
import pandas as pd

from ..config.config_details import BUF_MODEL_ENDPOINT, BUF_DEPLOYMENT_NAME, BUF_MODEL_API_KEY, BUF_DATAROBOT_KEY
from ..config.utils import logger, measure_execution_time

class DataRobotPredictionError(Exception):
    """Raised if there are issues getting predictions from DataRobot"""
 
def make_datarobot_deployment_predictions(data, deployment_id):
    """
    Make predictions on data provided using DataRobot deployment_id provided.
    See docs for details:
         https://app.datarobot.com/docs/predictions/api/dr-predapi.html
 
    Parameters
    ----------
    data : str
        If using CSV as input:
        Feature1,Feature2
        numeric_value,string
 
        Or if using JSON as input:
        [{"Feature1":numeric_value,"Feature2":"string"}]
 
    deployment_id : str
        The ID of the deployment to make predictions with.
 
    Returns
    -------
    Response schema:
        https://app.datarobot.com/docs/predictions/api/dr-predapi.html#response-schema
 
    Raises
    ------
    DataRobotPredictionError if there are issues getting predictions from DataRobot
    """
    try:
        # Set HTTP headers. The charset should match the contents of the file.
        headers = {
            # 'Content-Type': 'text/plain; charset=UTF-8',
            'Content-Type': 'application/json; charset=UTF-8',
            'Authorization': 'Bearer {}'.format(BUF_MODEL_API_KEY),
            'DataRobot-Key': BUF_DATAROBOT_KEY,
        }

        url = BUF_MODEL_ENDPOINT.format(deployment_id=deployment_id)

        # Prediction Explanations:
        # See the documentation for more information:
        # https://app.datarobot.com/docs/predictions/api/dr-predapi.html#request-pred-explanations
        # Should you wish to include Prediction Explanations or Prediction Warnings in the result,
        # Change the parameters below accordingly, and remove the comment from the params field below:

        params = {
            # If explanations are required, uncomment the line below
            'maxExplanations': 3,
            'thresholdHigh': 0.5,
            'thresholdLow': 0.15,
            # If text explanations are required, uncomment the line below.
            # 'maxNgramExplanations': 'all',
            # Uncomment this for Prediction Warnings, if enabled for your deployment.
            # 'predictionWarningEnabled': 'true',
        }
        # Make API request for predictions
        predictions_response = requests.post(
            url,
            data=data,
            headers=headers,
            # Prediction Explanations:
            params=params,
        )
        _raise_dataroboterror_for_status(predictions_response)
        # Return a Python dict following the schema in the documentation
        # print(predictions_response.json())

        result = predictions_response.json()
        api_result = result["data"]

        # # Creating 'id' column from passthroughValues['id']
        api_result = pd.json_normalize(api_result)
        api_result.rename(columns = {'passthroughValues.id':'id'}, inplace = True)
        # print(api_result.columns)

        # # Alternate way for Creating 'id' column from passthroughValues['id']
        # for d in api_result:
        #   d['id'] = d['passthroughValues']['id']
        #   del d['passthroughValues']
        # api_result = pd.DataFrame.from_dict(api_result, orient ='columns')

        # logger.info(f"PROCESSED API RESULT:\n{api_result}") ## Very Long Response
        logger.info(f"Inferencing Completed!")

        return api_result
    except Exception as exc:
        raise DataRobotPredictionError(exc)
 
def _raise_dataroboterror_for_status(response):
    """Raise DataRobotPredictionError if the request fails along with the response returned"""
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError:
        err_msg = '{code} Error: {msg}'.format(
            code=response.status_code, msg=response.text)
        logger.critical(f"[ERROR] INFERENCE ENDPOINT ERROR: {err_msg}")
        raise DataRobotPredictionError(err_msg)
 
@measure_execution_time
def datarobot_buf_predict(data):
    """
    Return an exit code on script completion or error. Codes > 0 are errors to the shell.
    Also useful as a usage demonstration of
    `make_datarobot_deployment_predictions(data, deployment_id)`
    """
    deployment_id = BUF_DEPLOYMENT_NAME
    print('waiting for results from DataRobot Model...')
    logger.info('waiting for results from DataRobot Model...')
    try:
        predictions = make_datarobot_deployment_predictions(data, deployment_id)
        # print(json.dumps(predictions, indent=4))
        return predictions
    except DataRobotPredictionError as exc:
        print(exc)
        logger.critical(f"[ERROR] INFERENCE ENDPOINT ERROR: {str(exc)}")
        raise DataRobotPredictionError(exc)