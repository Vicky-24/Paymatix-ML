NUM_OF_DATA=500

SF_ACCOUNT="BPSYWTN-HEXAWARE"
SF_USER="MOHAMMADA1"
SF_PASSWORD="Paymatix@123!"
SF_ROLE="SYSADMIN"
SF_DATABASE="ML_MODELS"
SF_SCHEMA="MODELS"
SF_WAREHOUSE="PAYMATIX_ML_WH"

FROM_EMAIL = 'harvisbanking@gmail.com'
RECIPIENT = ['bhims2@hexaware.com', 'senthilkumarb4@hexaware.com' 'arunkumarl@hexaware.com', 'rajeshsankark@hexaware.com']  # 'sravishankar@hexaware.com', 'mohammadA1@hexaware.com', 'amansinghc@hexaware.com']
SMTP_PORT = 587
SMTP_SERVER = 'smtp.gmail.com'
EMAILPASSWORD = 'rrnmymxqxfeznnwu'
EMAIL_TIMEOUT=300

BUF_TABLE_NAME="BUF_CUSTOMER_TABLE"
BUF_UDF="BATCH_PREDICT_BUF_SCORE"
BUF_TRAIN_SPROC="TRAIN_BUF_MODEL"
BUF_PREDICTED_TABLE_NAME="PREDICTED_BUF_CUSTOMER_TABLE"
TOLERANT_CUSTOMER_SCORE=37
BUF_EMAILSUBJECT = 'BUF PREDICTIONS REPORT | Snowflake'
BUF_EMAILBODY = """\
    <html>
    <body>
        <p>Hi,<br>
        Please find attached the list of customers deemed to have fraudulent transactions based on BUF predictions.\n\n
        </p>
        Thanks.
    </body>
    </html>
"""

CHURN_TABLE_NAME="CHURN"
CHURN_UDF="batch_predict_churn_score"
CHURN_TRAIN_SPROC="TRAIN_CHURN_MODEL"
CHURN_PREDICTED_TABLE_NAME="PREDICTED_CHURN_DATA"
CHURN_EMAILSUBJECT = 'New Offers for your Account'
CHURN_EMAILBODY = """\
    <html>
        <body>
            <div>Hi,</div><br>
            <div>You have received the following offer(s)!<br><br>
            +{offer}+
            </div><br><br><br>
            <div>Thanks & Regards,</div><br>
            <div>Hexaware Banking</div>
            <img src='cid:leftSideImage' style='float:left;width:20%;height:20%;'/>
        </body>
    </html>
"""